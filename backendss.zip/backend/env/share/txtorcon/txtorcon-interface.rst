:mod:`txtorcon.interface` Module
================================

Note: the Onion interfaces are defined in :ref:`onion_api`

interface.IStreamAttacher
-------------------------
.. autointerface:: txtorcon.interface.IStreamAttacher

interface.IStreamListener
-------------------------
.. autointerface:: txtorcon.interface.IStreamListener

interface.ICircuitListener
--------------------------
.. autointerface:: txtorcon.interface.ICircuitListener

interface.ICircuitContainer
---------------------------
.. autointerface:: txtorcon.interface.ICircuitContainer

interface.IRouterContainer
--------------------------
.. autointerface:: txtorcon.interface.IRouterContainer

interface.ITorControlProtocol
-----------------------------
.. autointerface:: txtorcon.interface.ITorControlProtocol
