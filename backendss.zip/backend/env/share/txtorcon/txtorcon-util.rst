:mod:`txtorcon.util` Module
===========================

util.NetLocation
----------------
.. autoclass:: txtorcon.util.NetLocation

util.process_from_address
-------------------------
.. automethod:: txtorcon.util.process_from_address

util.delete_file_or_tree
------------------------
.. automethod:: txtorcon.util.delete_file_or_tree
